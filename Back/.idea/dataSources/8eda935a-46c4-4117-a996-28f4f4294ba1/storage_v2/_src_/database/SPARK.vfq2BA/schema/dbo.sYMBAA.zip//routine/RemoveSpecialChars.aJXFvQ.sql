CREATE PROCEDURE RemoveSpecialChars
AS
BEGIN
    DECLARE @SpecialChars VARCHAR(50) = '%[^a-zA-Z0-9 ]%';
    DECLARE @Position INT;
    DECLARE @CardName NVARCHAR(MAX);

    DECLARE cur CURSOR FOR
    SELECT card_name FROM PORTEUR.card;

    OPEN cur;

    FETCH NEXT FROM cur INTO @CardName;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @Position = PATINDEX(@SpecialChars, @CardName);
        WHILE @Position > 0
        BEGIN
            SET @CardName = STUFF(@CardName, @Position, 1, ' ');
            SET @Position = PATINDEX(@SpecialChars, @CardName);
        END;

        UPDATE PORTEUR.card
        SET card_name = @CardName
        WHERE CURRENT OF cur;

        FETCH NEXT FROM cur INTO @CardName;
    END;

    CLOSE cur;
    DEALLOCATE cur;
END;
go

